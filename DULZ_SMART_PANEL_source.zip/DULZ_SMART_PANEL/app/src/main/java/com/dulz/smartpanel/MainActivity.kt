package com.dulz.smartpanel

import android.app.*
import android.app.usage.StorageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dulz_settings", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var accent = Color.rgb(255, 65, 75)
    private var dark = 0xFF101116.toInt()
    private var card = 0xFF1B1D25.toInt()
    private val dp get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyTheme()
        buildShell()
        showDashboard()
    }

    private fun applyTheme() {
        when (prefs.getString("theme", "red")) {
            "blue" -> accent = Color.rgb(55, 145, 255)
            "white" -> accent = Color.WHITE
            else -> accent = Color.rgb(255, 65, 75)
        }
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(14))
        }
        val brand = TextView(this).apply {
            text = "DULZ  /  SMART PANEL"
            textSize = 19f; setTextColor(Color.WHITE); setTypeface(null, 1)
        }
        val sub = TextView(this).apply {
            text = "SMART CONTROL CENTER  •  v1.0"
            textSize = 10f; setTextColor(accent)
        }
        header.addView(brand); header.addView(sub)
        root.addView(header)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(8))
        }
        listOf("Home", "Control", "Gaming", "Security", "Settings").forEach { label ->
            val b = TextView(this).apply {
                text = label; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); setPadding(dp(7), dp(12), dp(7), dp(12))
                setOnClickListener { when(label) {
                    "Home" -> showDashboard()
                    "Control" -> showControl()
                    "Gaming" -> showGaming()
                    "Security" -> showSecurity()
                    else -> showSettings()
                } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun clear(title: String, subtitle: String) {
        content.removeAllViews()
        val h = TextView(this).apply {
            text = title; textSize = 24f; setTextColor(Color.WHITE); setTypeface(null, 1)
        }
        val s = TextView(this).apply {
            text = subtitle; textSize = 12f; setTextColor(0xFF9EA3B2.toInt())
            setPadding(0, dp(4), 0, dp(16))
        }
        content.addView(h); content.addView(s)
    }

    private fun card(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(card)
        }
        val t = TextView(this).apply {
            text = title; textSize = 14f; setTextColor(accent); setTypeface(null, 1)
        }
        val b = TextView(this).apply {
            text = body; textSize = 13f; setTextColor(Color.WHITE); setPadding(0, dp(7), 0, 0)
        }
        box.addView(t); box.addView(b)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10)
        content.addView(box, lp)
        return box
    }

    private fun button(label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label; isAllCaps = false
            setOnClickListener { onClick() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(8)
        content.addView(b, lp)
    }

    private fun memoryText(): String {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val total = info.totalMem / 1024 / 1024
        val avail = info.availMem / 1024 / 1024
        return "${total-avail} MB digunakan perkiraan • $avail MB tersedia • total $total MB"
    }

    private fun storageText(): String {
        val stat = StatFs(filesDir.absolutePath)
        val total = stat.totalBytes / 1024 / 1024 / 1024
        val free = stat.availableBytes / 1024 / 1024 / 1024
        return "${total-free} GB terpakai • $free GB tersedia • total $total GB (volume aplikasi)"
    }

    private fun batteryInfo(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra("level", -1) ?: -1
        val scale = i?.getIntExtra("scale", 100) ?: 100
        val temp = i?.getIntExtra("temperature", -1) ?: -1
        val pct = if (level >= 0) level * 100 / scale.coerceAtLeast(1) else -1
        val c = if (temp >= 0) String.format(Locale.US, "%.1f°C", temp / 10f) else "Tidak tersedia"
        return "$pct% • Suhu baterai: $c"
    }

    private fun showDashboard() {
        clear("Dashboard", "Ringkasan kondisi perangkat secara langsung")
        card("PERANGKAT", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
        card("BATTERY", batteryInfo())
        card("MEMORY", memoryText())
        card("STORAGE", storageText())
        card("CPU / HARDWARE", "${Runtime.getRuntime().availableProcessors()} logical cores\n${Build.HARDWARE} • ${Build.SUPPORTED_ABIS.joinToString()}")
        card("WAKTU", java.text.SimpleDateFormat("EEEE, dd MMM yyyy  •  HH:mm:ss", Locale.getDefault()).format(java.util.Date()))
        button("Refresh data") { showDashboard() }
        button("Buka pengaturan perangkat") { open(Settings.ACTION_SETTINGS) }
    }

    private fun showControl() {
        clear("Smart Control", "Kontrol yang diizinkan Android dan shortcut sistem")
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        card("VOLUME MEDIA", "Atur volume media perangkat")
        val volume = SeekBar(this).apply {
            this.max = max; progress = current
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if(user) audio.setStreamVolume(AudioManager.STREAM_MUSIC,p,0) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(volume)
        card("KECERAHAN", "Memerlukan izin Modify System Settings")
        val bright = SeekBar(this).apply {
            max = 255
            progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 120 }
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if(user && Settings.System.canWrite(this@MainActivity)) Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        content.addView(bright)
        button("Izinkan pengaturan kecerahan") { requestWriteSettings() }
        button("Wi-Fi settings") { open(Settings.ACTION_WIFI_SETTINGS) }
        button("Bluetooth settings") { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
        button("Jaringan seluler") { open(Settings.ACTION_NETWORK_OPERATOR_SETTINGS) }
        button("Rotasi & tampilan") { open(Settings.ACTION_DISPLAY_SETTINGS) }
        button("Timeout layar") { open(Settings.ACTION_DISPLAY_SETTINGS) }
        button("Buka semua pengaturan suara") { open(Settings.ACTION_SOUND_SETTINGS) }
    }

    private fun showGaming() {
        clear("Gaming Mode", "Shortcut game dan kontrol gangguan. Tidak mengubah FPS atau performa game.")
        card("GAME DASHBOARD", "Pantau RAM dan baterai sebelum bermain. Tambahkan game dari daftar aplikasi yang terpasang.")
        card("MEMORY", memoryText())
        card("BATTERY", batteryInfo())
        button("Pilih game dari aplikasi terpasang") { showGamePicker() }
        button("Aktifkan / atur Jangan Ganggu") { requestDnd() }
        button("Buka pengaturan game Android") { open(Settings.ACTION_APPLICATION_SETTINGS) }
        button("Aktifkan Floating Panel") { requestOverlayAndStart() }
    }

    private fun showGamePicker() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        clear("Pilih aplikasi", "Ketuk untuk membuka aplikasi")
        apps.take(80).forEach { info ->
            button(info.loadLabel(pm).toString()) {
                val launch = pm.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) startActivity(launch)
                else Toast.makeText(this, "Aplikasi tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSecurity() {
        clear("Security Center", "Informasi dasar dan pintasan keamanan Android")
        card("ANDROID", "Versi ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}\nSecurity patch: ${Build.VERSION.SECURITY_PATCH}")
        card("STATUS IZIN", "Overlay: ${Settings.canDrawOverlays(this)}\nModify Settings: ${Settings.System.canWrite(this)}\nDND: ${getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted}")
        card("PRIVASI", "Aplikasi tidak meminta kontak, SMS, mikrofon, kamera, atau lokasi. Tidak ada pemindaian/penghapusan file otomatis.")
        button("App permissions") { openAppDetails() }
        button("Security settings") { open(Settings.ACTION_SECURITY_SETTINGS) }
        button("Privacy settings") { open(Settings.ACTION_PRIVACY_SETTINGS) }
        button("Periksa status izin") { showSecurity() }
    }

    private fun showSettings() {
        clear("Settings", "Personalisasi dan status izin aplikasi")
        button("Tema merah") { prefs.edit().putString("theme","red").apply(); applyTheme(); buildShell(); showSettings() }
        button("Tema biru") { prefs.edit().putString("theme","blue").apply(); applyTheme(); buildShell(); showSettings() }
        button("Tema putih") { prefs.edit().putString("theme","white").apply(); applyTheme(); buildShell(); showSettings() }
        button("Izin floating panel") { requestOverlayAndStart() }
        button("Izin pengaturan sistem") { requestWriteSettings() }
        button("Akses Jangan Ganggu") { requestDnd() }
        button("Pengaturan notifikasi aplikasi") {
            if (Build.VERSION.SDK_INT >= 26) open(Settings.ACTION_APP_NOTIFICATION_SETTINGS, "android.provider.extra.APP_PACKAGE" to packageName)
            else open(Settings.ACTION_SETTINGS)
        }
        button("Informasi aplikasi & izin") { openAppDetails() }
        card("TENTANG", "DULZ SMART PANEL\nDeveloper: Dulz Strm\nVersion: 1.0\nData disimpan lokal di perangkat.")
    }

    private fun open(action: String, extra: Pair<String,String>? = null) {
        try {
            val i = Intent(action)
            extra?.let { i.putExtra(it.first, it.second) }
            startActivity(i)
        } catch (_: Exception) { Toast.makeText(this, "Pengaturan tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show() }
    }

    private fun requestOverlayAndStart() {
        if (Settings.canDrawOverlays(this)) startPanel()
        else {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain untuk mengaktifkan panel.", Toast.LENGTH_LONG).show()
            open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package" to packageName)
        }
    }

    private fun startPanel() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val i = Intent(this, FloatingPanelService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            Toast.makeText(this, "Floating panel dimulai", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak dapat memulai panel. Periksa izin dan pengaturan baterai.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestWriteSettings() {
        if (!Settings.System.canWrite(this)) open(Settings.ACTION_MANAGE_WRITE_SETTINGS, "package" to packageName)
        else Toast.makeText(this, "Izin pengaturan sistem sudah aktif", Toast.LENGTH_SHORT).show()
    }

    private fun requestDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return
        }
        try {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            Toast.makeText(this, "Filter Jangan Ganggu prioritas diaktifkan", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "Android menolak perubahan DND", Toast.LENGTH_SHORT).show() }
    }

    private fun openAppDetails() {
        open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package" to packageName)
    }

    override fun onResume() {
        super.onResume()
    }

    private fun dp(v: Int) = (v * dp).toInt()
}
