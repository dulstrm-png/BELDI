package com.dulz.smartpanel

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingPanelService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        createNotification()
        showPanel()
    }

    private fun createNotification() {
        val channelId = "dulz_panel"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Floating Panel", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId)
        else Notification.Builder(this)
        notification.setContentTitle("DULZ SMART PANEL")
            .setContentText("Floating shortcuts are active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
        startForeground(101, notification.build())
    }

    @Suppress("DEPRECATION")
    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xEE17171D.toInt())
        }
        val title = TextView(this).apply {
            text = "DULZ  •  PANEL"
            setTextColor(0xFFFF5252.toInt())
            textSize = 13f
            setPadding(0, 0, 0, 10)
        }
        box.addView(title)
        fun action(label: String, intent: Intent) {
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent) }
            }
            box.addView(b, LinearLayout.LayoutParams(-1, -2))
        }
        action("Wi-Fi", Intent(Settings.ACTION_WIFI_SETTINGS))
        action("Bluetooth", Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        action("Display", Intent(Settings.ACTION_DISPLAY_SETTINGS))
        val close = Button(this).apply {
            text = "Tutup panel"
            setOnClickListener { stopSelf() }
        }
        box.addView(close)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }

        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        // Drag from the title only, so the shortcut buttons remain clickable.
        title.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = params.x; initialY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX - (event.rawX - startX).toInt()
                    params.y = initialY + (event.rawY - startY).toInt()
                    windowManager?.updateViewLayout(box, params)
                    true
                }
                else -> false
            }
        }
        panel = box
        windowManager?.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
