# DULZ SMART PANEL v1.0

Native Android project written in Kotlin. Minimum Android 8.0 (API 26).

## Features implemented
- Device model, Android version, hardware/ABI and CPU logical-core count
- Battery percentage and battery temperature (when reported by Android)
- Memory snapshot via ActivityManager
- Storage volume snapshot for the app's data volume
- Media volume control
- Screen brightness control after user grants Modify System Settings
- Wi-Fi, Bluetooth, network, display and sound Settings shortcuts
- Installed-app launcher list for selecting/opening games
- DND access flow
- Draggable floating overlay with Wi-Fi/Bluetooth/Display shortcuts
- Basic security and permission status page
- Local theme preference (red/blue/white)

## Important limitations
Android does not allow ordinary apps to silently toggle Wi-Fi on modern versions, force game FPS, clear other apps' memory, or read all CPU telemetry. This app uses official Settings screens where direct changes are restricted.
The storage figure is the app's data volume, not necessarily the entire physical device storage on every Android vendor build.
CPU details are limited to information exposed by the public SDK.
Floating panel needs the user to grant Display over other apps. DND needs Notification Policy access.
The app does not use root or Accessibility Service.

## Build
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle runtime when prompted.
3. Sync Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Package
`com.dulz.smartpanel`
